<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-18 07:59:19 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ')' C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\config\database.php 97
ERROR - 2020-12-18 08:05:50 --> 404 Page Not Found: /index
ERROR - 2020-12-18 08:05:50 --> 404 Page Not Found: /index
ERROR - 2020-12-18 08:23:49 --> 404 Page Not Found: /index
ERROR - 2020-12-18 08:23:49 --> 404 Page Not Found: /index
ERROR - 2020-12-18 11:37:53 --> 404 Page Not Found: /index
ERROR - 2020-12-18 11:37:53 --> 404 Page Not Found: /index
ERROR - 2020-12-18 11:50:49 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-18 17:06:31 --> 404 Page Not Found: /index
ERROR - 2020-12-18 17:06:31 --> 404 Page Not Found: /index
ERROR - 2020-12-18 17:12:47 --> 404 Page Not Found: /index
ERROR - 2020-12-18 17:12:53 --> 404 Page Not Found: /index
ERROR - 2020-12-18 17:12:53 --> 404 Page Not Found: /index
ERROR - 2020-12-18 19:04:05 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-18 19:08:34 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2020-12-18 19:08:48 --> 404 Page Not Found: /index
ERROR - 2020-12-18 19:08:48 --> 404 Page Not Found: /index
ERROR - 2020-12-18 19:13:19 --> 404 Page Not Found: /index
ERROR - 2020-12-18 19:13:19 --> 404 Page Not Found: /index
