<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-28 18:38:11 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:38:11 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:48:07 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:48:07 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:52:06 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:52:06 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:53:35 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:53:35 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:53:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-28 18:54:15 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:15 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:20 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:20 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:34 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:34 --> 404 Page Not Found: /index
ERROR - 2020-12-28 18:54:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-28 19:15:51 --> 404 Page Not Found: /index
ERROR - 2020-12-28 19:15:51 --> 404 Page Not Found: /index
ERROR - 2020-12-28 19:15:53 --> 404 Page Not Found: /index
ERROR - 2020-12-28 19:20:10 --> 404 Page Not Found: /index
ERROR - 2020-12-28 19:20:10 --> 404 Page Not Found: /index
ERROR - 2020-12-28 19:20:10 --> 404 Page Not Found: /index
