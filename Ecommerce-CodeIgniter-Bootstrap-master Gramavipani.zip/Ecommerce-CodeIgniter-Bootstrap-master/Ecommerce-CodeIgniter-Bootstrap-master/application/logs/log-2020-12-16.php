<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-16 21:15:13 --> 404 Page Not Found: /index
ERROR - 2020-12-16 21:15:19 --> 404 Page Not Found: /index
ERROR - 2020-12-16 21:15:19 --> 404 Page Not Found: /index
ERROR - 2020-12-16 21:15:23 --> 404 Page Not Found: /index
ERROR - 2020-12-16 21:15:23 --> 404 Page Not Found: /index
ERROR - 2020-12-16 21:24:33 --> Severity: error --> Exception: Call to undefined method Home_admin_model::getValueStore() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\models\Public_model.php 14
