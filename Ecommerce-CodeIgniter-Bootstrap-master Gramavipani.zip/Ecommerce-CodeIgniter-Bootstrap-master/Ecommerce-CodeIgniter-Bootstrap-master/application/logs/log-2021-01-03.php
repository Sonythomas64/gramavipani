<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-03 19:18:54 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:18:54 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:18:58 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:18:59 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:17 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:17 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:29 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:29 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:48 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:19:48 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:20:00 --> 404 Page Not Found: /index
ERROR - 2021-01-03 19:20:00 --> 404 Page Not Found: /index
