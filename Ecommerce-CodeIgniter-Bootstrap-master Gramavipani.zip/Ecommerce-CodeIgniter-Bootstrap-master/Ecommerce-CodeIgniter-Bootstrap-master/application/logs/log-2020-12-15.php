<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 20:14:08 --> 404 Page Not Found: /index
ERROR - 2020-12-15 20:14:08 --> 404 Page Not Found: /index
ERROR - 2020-12-15 20:14:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-15 20:15:32 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2020-12-15 20:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-15 20:19:13 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
