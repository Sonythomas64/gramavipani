<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-19 11:06:48 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:06:49 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:07:51 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:07:51 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:07:51 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:08:02 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:08:02 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:15:58 --> 404 Page Not Found: /index
ERROR - 2020-12-19 11:15:58 --> 404 Page Not Found: /index
