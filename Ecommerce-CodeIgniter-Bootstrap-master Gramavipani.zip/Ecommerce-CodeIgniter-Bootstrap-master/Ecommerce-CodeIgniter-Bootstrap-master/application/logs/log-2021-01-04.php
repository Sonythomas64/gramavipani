<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-04 16:00:56 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:00:56 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:52:58 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:52:58 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:55:36 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\_parts\header.php 94
ERROR - 2021-01-04 16:55:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\_parts\header.php 94
ERROR - 2021-01-04 16:55:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\shopping_cart.php 9
ERROR - 2021-01-04 16:56:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2021-01-04 16:56:44 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:56:44 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\onepage\checkout.php 43
ERROR - 2021-01-04 16:57:06 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:06 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:06 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\checkout.php 36
ERROR - 2021-01-04 16:57:31 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:32 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:32 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\clothesshop\checkout.php 36
ERROR - 2021-01-04 16:57:54 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:54 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:57:54 --> 404 Page Not Found: /index
ERROR - 2021-01-04 16:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 16:58:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 16:58:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:00:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:21:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:21:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:27:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:28:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:28:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-04 18:29:10 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
