<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-11 17:30:14 --> Query error: Table 'test1.value_store' doesn't exist - Invalid query: SELECT value FROM value_store WHERE thekey = 'outOfStock' LIMIT 1
ERROR - 2020-12-11 18:02:48 --> Query error: Table 'test1.languages' doesn't exist - Invalid query: SELECT *
FROM `languages`
WHERE `abbr` = ''
ERROR - 2020-12-11 18:06:40 --> Query error: Table 'test1.seo_pages_translations' doesn't exist - Invalid query: SELECT *
FROM `seo_pages_translations`
WHERE `page_type` = 'home'
AND `abbr` = 'en'
ERROR - 2020-12-11 18:08:05 --> Query error: Table 'test1.shop_categories_translations' doesn't exist - Invalid query: SELECT `shop_categories`.`sub_for`, `shop_categories`.`id`, `shop_categories_translations`.`name`
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2020-12-11 18:09:09 --> Query error: Table 'test1.shop_categories' doesn't exist - Invalid query: SELECT `shop_categories`.`sub_for`, `shop_categories`.`id`, `shop_categories_translations`.`name`
FROM `shop_categories_translations`
INNER JOIN `shop_categories` ON `shop_categories`.`id` = `shop_categories_translations`.`for_id`
WHERE `abbr` = 'en'
ORDER BY `position` ASC
ERROR - 2020-12-11 18:09:55 --> Query error: Table 'test1.products' doesn't exist - Invalid query: SELECT SUM(IF(quantity<=0,1,0)) as out_of_stock, SUM(IF(quantity>0,1,0)) as in_stock FROM products WHERE visibility = 1
ERROR - 2020-12-11 18:10:50 --> Query error: Table 'test1.products_translations' doesn't exist - Invalid query: SELECT `vendors`.`url` as `vendor_url`, `products`.`id`, `products`.`quantity`, `products`.`image`, `products`.`url`, `products_translations`.`price`, `products_translations`.`title`, `products_translations`.`old_price`
FROM `products`
LEFT JOIN `products_translations` ON `products_translations`.`for_id` = `products`.`id`
LEFT JOIN `vendors` ON `vendors`.`id` = `products`.`vendor_id`
WHERE `products_translations`.`abbr` = 'en'
AND `visibility` = 1
AND `quantity` > 0
ORDER BY `products`.`procurement` DESC
 LIMIT 5
ERROR - 2020-12-11 18:11:48 --> Query error: Table 'test1.vendors' doesn't exist - Invalid query: SELECT `vendors`.`url` as `vendor_url`, `products`.`id`, `products`.`quantity`, `products`.`image`, `products`.`url`, `products_translations`.`price`, `products_translations`.`title`, `products_translations`.`old_price`
FROM `products`
LEFT JOIN `products_translations` ON `products_translations`.`for_id` = `products`.`id`
LEFT JOIN `vendors` ON `vendors`.`id` = `products`.`vendor_id`
WHERE `products_translations`.`abbr` = 'en'
AND `visibility` = 1
AND `quantity` > 0
ORDER BY `products`.`procurement` DESC
 LIMIT 5
ERROR - 2020-12-11 18:12:43 --> Query error: Table 'test1.blog_posts' doesn't exist - Invalid query: SELECT `blog_posts`.`id`, `blog_translations`.`title`, `blog_translations`.`description`, `blog_posts`.`url`, `blog_posts`.`time`, `blog_posts`.`image`
FROM `blog_posts`
LEFT JOIN `blog_translations` ON `blog_translations`.`for_id` = `blog_posts`.`id`
WHERE `blog_translations`.`abbr` = 'en'
 LIMIT 5
ERROR - 2020-12-11 18:14:00 --> Query error: Table 'test1.blog_translations' doesn't exist - Invalid query: SELECT `blog_posts`.`id`, `blog_translations`.`title`, `blog_translations`.`description`, `blog_posts`.`url`, `blog_posts`.`time`, `blog_posts`.`image`
FROM `blog_posts`
LEFT JOIN `blog_translations` ON `blog_translations`.`for_id` = `blog_posts`.`id`
WHERE `blog_translations`.`abbr` = 'en'
 LIMIT 5
ERROR - 2020-12-11 18:15:16 --> Query error: Table 'test1.brands' doesn't exist - Invalid query: SELECT *
FROM `brands`
ERROR - 2020-12-11 18:18:24 --> Query error: Table 'test1.cookie_law' doesn't exist - Invalid query: SELECT `link`, `theme`, `message`, `button_text`, `learn_more`
FROM `cookie_law`
INNER JOIN `cookie_law_translations` ON `cookie_law_translations`.`for_id` = `cookie_law`.`id`
WHERE `cookie_law_translations`.`abbr` = 'en'
AND `cookie_law`.`visibility` = '1'
ERROR - 2020-12-11 18:19:45 --> Query error: Table 'test1.cookie_law_translations' doesn't exist - Invalid query: SELECT `link`, `theme`, `message`, `button_text`, `learn_more`
FROM `cookie_law`
INNER JOIN `cookie_law_translations` ON `cookie_law_translations`.`for_id` = `cookie_law`.`id`
WHERE `cookie_law_translations`.`abbr` = 'en'
AND `cookie_law`.`visibility` = '1'
ERROR - 2020-12-11 18:21:16 --> 404 Page Not Found: /index
ERROR - 2020-12-11 18:22:04 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-11 18:22:04 --> 404 Page Not Found: /index
ERROR - 2020-12-11 18:22:09 --> Query error: Table 'test1.bank_accounts' doesn't exist - Invalid query: SELECT * FROM bank_accounts LIMIT 1
ERROR - 2020-12-11 18:22:11 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-11 18:22:11 --> 404 Page Not Found: /index
ERROR - 2020-12-11 18:22:19 --> 404 Page Not Found: /index
ERROR - 2020-12-11 18:22:21 --> Query error: Table 'test1.bank_accounts' doesn't exist - Invalid query: SELECT * FROM bank_accounts LIMIT 1
ERROR - 2020-12-11 18:22:25 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:26:56 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:27:17 --> Query error: Table 'test1.bank_accounts' doesn't exist - Invalid query: SELECT * FROM bank_accounts LIMIT 1
ERROR - 2020-12-11 19:29:23 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:29:24 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:31:19 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-11 19:31:19 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:31:39 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:31:51 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:31:52 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:11 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:21 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:24 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:27 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:29 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:32:33 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:05 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:09 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:11 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:17 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:32 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:38 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:33:45 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:33:45 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:34:44 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:34:44 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:34:49 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:34:50 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:34:50 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:34:50 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:34:55 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:34:56 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:34:57 --> 404 Page Not Found: /index
ERROR - 2020-12-11 19:40:10 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-11 19:40:11 --> 404 Page Not Found: /index
