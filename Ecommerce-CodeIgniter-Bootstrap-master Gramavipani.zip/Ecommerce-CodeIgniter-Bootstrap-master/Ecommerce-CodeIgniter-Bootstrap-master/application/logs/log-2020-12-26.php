<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-26 19:58:45 --> 404 Page Not Found: /index
ERROR - 2020-12-26 19:58:45 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:29:18 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:29:18 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:20 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:20 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:33 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:33 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:55 --> 404 Page Not Found: /index
ERROR - 2020-12-26 20:41:55 --> 404 Page Not Found: /index
