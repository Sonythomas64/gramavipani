<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-12 06:10:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:12:50 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:12:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:12:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-12 06:12:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:18 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-12 06:13:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:20 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-12 06:13:20 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:25 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-12 06:13:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 06:13:31 --> 404 Page Not Found: /index
ERROR - 2020-12-12 08:08:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 08:21:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 08:21:52 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-12 08:21:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 08:21:55 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-12 08:21:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 08:21:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:48:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:48:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:48:17 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:58:17 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:14 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 15:59:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:02:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:02:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:02:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:02:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:04:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:04:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:04:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:14:28 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-12 16:14:31 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-12 16:18:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:19:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:19:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:19:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:26:48 --> Query error: Table 'test1.orders' doesn't exist - Invalid query: SELECT count(id) as num FROM `orders` WHERE viewed = 0
ERROR - 2020-12-12 16:31:20 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:31:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:31:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:31:43 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:31:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:31:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:31:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:31:56 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:31:57 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:32:03 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:32:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:32:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:38:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:38:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:38:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:38:43 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:38:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:38:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:41:10 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:41:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:41:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:41:12 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:41:13 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:41:13 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:43:10 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:43:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:43:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:43:17 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:44:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:45:01 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:46:31 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:46:38 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:46:53 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:46:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:46:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:49:35 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 16:49:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:49:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 16:50:06 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 6
ERROR - 2020-12-12 16:50:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\shopping_cart.php 8
ERROR - 2020-12-12 17:23:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 17:23:27 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:23:27 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:25:40 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 17:25:41 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:25:41 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:25:42 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 17:25:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:25:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:26:51 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 17:26:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:26:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:27:21 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\_parts\header.php 218
ERROR - 2020-12-12 17:27:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:27:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:34:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:34:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:34:44 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 11
ERROR - 2020-12-12 17:34:50 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:34:50 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:35:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:35:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:36:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:37:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:37:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:52:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:52:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 17:52:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 11
ERROR - 2020-12-12 17:53:34 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:53:34 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 17:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:54:19 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 17:55:08 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:59:55 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:59:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 17:59:55 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 18:00:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 18:00:27 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 18:00:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 18:00:42 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 18:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 18:00:45 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 18:01:02 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 18:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 29
ERROR - 2020-12-12 18:01:02 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 57
ERROR - 2020-12-12 18:03:59 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 59
ERROR - 2020-12-12 18:05:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:07:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:07:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:07:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:08:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:08:47 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:09:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:12:43 --> Could not find the language line "user_order_history"
ERROR - 2020-12-12 18:15:33 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:15:33 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:18:47 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:18:47 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:28:10 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2020-12-12 18:28:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:28:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:28:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:28:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:28:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:28:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:28:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:29:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:33:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:33:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:37:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:37:27 --> Could not find the language line "user_order_history"
ERROR - 2020-12-12 18:40:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:40:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:40:24 --> Could not find the language line "user_order_history"
ERROR - 2020-12-12 18:40:37 --> Could not find the language line "user_order_history"
ERROR - 2020-12-12 18:43:48 --> Could not find the language line "user_order_history"
ERROR - 2020-12-12 18:43:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 18:44:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:44:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:47:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:47:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:54:10 --> Severity: error --> Exception: Call to undefined function gmt_to_local() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 18:54:46 --> Severity: error --> Exception: Call to undefined function gmt_to_local() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 18:54:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:54:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:55:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 18:55:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:00:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:00:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:14 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:42 --> Severity: Warning --> localtime() expects parameter 1 to be int, string given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:05:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\modules\admin\views\settings\history.php 23
ERROR - 2020-12-12 19:16:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:16:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:17:28 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:17:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:17:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:18:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:34 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:19:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:21:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:21:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:21:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:23:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:23:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:24:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:24:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:26:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:26:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:26:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:26:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:27:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:27:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:30:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:30:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:30:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:31:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:31:20 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:31:20 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:31:50 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:34:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:34:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:34:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:38:19 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:38:19 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:40:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:40:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:40:20 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:41:40 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:41:40 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:43:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:44:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:48:20 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:48:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:48:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:48:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:49:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:49:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:49:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:50:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:50:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:50:35 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:52:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:53:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:53:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 19:53:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:10:35 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\shopping_cart.php 11
ERROR - 2020-12-12 20:14:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:14:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:14:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:14:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:14:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:14:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:51 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:15:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:16:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:16:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:19:39 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:19:39 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:19:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:19:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:20:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 20:20:39 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:22:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:22:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:23:14 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:23:14 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:23:27 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:32 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:32 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:51 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:26:51 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:29:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:29:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:29:36 --> Severity: Notice --> Undefined index: shopping_cart C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 20:29:36 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 20:29:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 20:29:36 --> Severity: Notice --> Undefined index: shopping_cart C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 52
ERROR - 2020-12-12 20:29:36 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 52
ERROR - 2020-12-12 20:29:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\core\Exceptions.php:271) C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\helpers\url_helper.php 564
ERROR - 2020-12-12 20:30:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:30:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:30:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:30:26 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:31:49 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:33:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:33:32 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:33:32 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:34:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:34:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:35:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:37:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:37:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:37:14 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:40:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:40:08 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:40:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:34 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:41 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:41 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:52 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:43:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:44:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:45:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:45:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:45:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:46:41 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:46:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:46:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:47:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:47:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:47:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:47:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:48:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:53:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:53:45 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:54:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:57:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:57:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:57:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:57:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:57:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:58:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:59:34 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:59:34 --> 404 Page Not Found: /index
ERROR - 2020-12-12 20:59:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:04 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:30 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:01:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:02:00 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:02:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:02:58 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:02:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:07 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:03:56 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:04:40 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:04:40 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:04:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:04:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:04:43 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:05:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:05:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:06:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:06:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:07:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:07:48 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:10:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:10:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:14:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:14:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:15:37 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:15:37 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:16:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:22:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:23:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:24:21 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:26:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:26:11 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:29:30 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2020-12-12 21:30:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:30:18 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:30:31 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:30:31 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:30:58 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:30:58 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:32:05 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2020-12-12 21:32:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:32:10 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:32:13 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:32:13 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:40:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:40:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:41:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:41:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:41:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:41:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:41:44 --> Severity: Notice --> Undefined index: shopping_cart C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 21:41:44 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 21:41:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 49
ERROR - 2020-12-12 21:41:45 --> Severity: Notice --> Undefined index: shopping_cart C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 52
ERROR - 2020-12-12 21:41:45 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\libraries\ShoppingCart.php 52
ERROR - 2020-12-12 21:41:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\core\Exceptions.php:271) C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\helpers\url_helper.php 564
ERROR - 2020-12-12 21:41:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 21:42:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 21:42:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:42:29 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:43:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:43:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:43:34 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:45:16 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:46:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:46:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:46:42 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:47:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:47:36 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:47:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:47:57 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:48:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:48:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:48:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:49:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:49:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:51:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:51:03 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:52:27 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:56:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:56:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:56:59 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:57:15 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:57:44 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:57:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:57:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 21:58:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:01:32 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:01:33 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:01:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:01:53 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:02:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:02:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:06 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:22 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:23 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:38 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:05:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:06:01 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:06:12 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:08:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:08:02 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:08:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:08:24 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:09:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:09:54 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:18:47 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:18:47 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:23:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:23:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:39:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:39:09 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:39:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-12 22:41:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:41:55 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:05 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:25 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:46 --> 404 Page Not Found: /index
ERROR - 2020-12-12 22:43:46 --> 404 Page Not Found: /index
