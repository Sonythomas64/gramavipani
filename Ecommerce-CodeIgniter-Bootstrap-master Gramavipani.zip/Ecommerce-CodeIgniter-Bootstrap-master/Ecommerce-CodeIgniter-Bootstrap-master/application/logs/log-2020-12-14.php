<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 11:04:06 --> 404 Page Not Found: /index
ERROR - 2020-12-14 11:04:06 --> 404 Page Not Found: /index
ERROR - 2020-12-14 11:04:15 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2020-12-14 11:08:38 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:08:53 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:08:57 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:09:08 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:09:10 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:09:20 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:09:28 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:09:32 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:47:11 --> 404 Page Not Found: /index
ERROR - 2020-12-14 11:47:11 --> 404 Page Not Found: /index
ERROR - 2020-12-14 11:47:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-14 11:48:09 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2020-12-14 11:49:01 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:49:05 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 11:49:26 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 16:19:38 --> 404 Page Not Found: /index
ERROR - 2020-12-14 16:19:38 --> 404 Page Not Found: /index
ERROR - 2020-12-14 16:21:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-14 16:22:22 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2020-12-14 16:23:07 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 16:23:20 --> 404 Page Not Found: /index
ERROR - 2020-12-14 16:23:20 --> 404 Page Not Found: /index
ERROR - 2020-12-14 16:23:21 --> Could not find the language line "user_order_history"
ERROR - 2020-12-14 16:23:32 --> Could not find the language line "user_order_history"
ERROR - 2020-12-14 16:27:40 --> Could not find the language line "user_order_history"
ERROR - 2020-12-14 20:42:19 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:42:19 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:42:21 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:42:21 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:44:07 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:44:08 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:45:29 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 20:45:48 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 20:49:42 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:49:42 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:49:43 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:49:43 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:58:52 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:58:52 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:00 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 20:59:21 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 20:59:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:38 --> 404 Page Not Found: /index
ERROR - 2020-12-14 20:59:39 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:05:39 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:05:39 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:07:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:07:36 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:07:37 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:07:37 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:10:21 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:10:21 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:10:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-14 21:11:31 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2020-12-14 21:12:43 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 21:13:44 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 21:13:49 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:13:49 --> 404 Page Not Found: /index
ERROR - 2020-12-14 21:14:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\greenlabel\checkout.php 43
ERROR - 2020-12-14 21:14:25 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2020-12-14 21:14:30 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 21:14:40 --> Could not find the language line "vendor_home_page"
ERROR - 2020-12-14 21:15:12 --> Could not find the language line "vendor_home_page"
