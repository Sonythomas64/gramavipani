<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-10 16:17:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-01-10 16:17:44 --> Unable to connect to the database
ERROR - 2021-01-10 16:19:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:19:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:19:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:20:57 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:20:57 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:20:57 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:22:37 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:22:37 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:22:37 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:29:55 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:29:55 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:29:56 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:36:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:36:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:36:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:49:07 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:49:07 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:49:07 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:54:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:54:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:55:39 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:55:39 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:55:39 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:56:38 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:56:38 --> 404 Page Not Found: /index
ERROR - 2021-01-10 16:56:38 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:00 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:00 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:00 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:54 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:54 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:01:55 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:04:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:04:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:04:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:09:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:09:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:09:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:10:30 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:10:30 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:10:30 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:16:11 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:16:11 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:16:11 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:22:06 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:22:06 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:22:06 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:23:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:23:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:23:15 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:25:44 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:25:44 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:28:12 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:28:21 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:28:38 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2021-01-10 17:28:52 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2021-01-10 17:28:57 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2021-01-10 17:28:58 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:28:59 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:29:07 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:36:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:36:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:38:27 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:39:37 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 17:39:41 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:39:41 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:41:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:41:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:41:43 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:43:29 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:43:32 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:43:33 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:43:33 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:45:00 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:45:00 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:53:45 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:53:45 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:53:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:05 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:05 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:08 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:08 --> 404 Page Not Found: /index
ERROR - 2021-01-10 17:56:08 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:04:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:04:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:06:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:06:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:06:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:06:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:13:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:13:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:13:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:13:22 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:22 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:13:22 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:13:57 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:14:16 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:24:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:24:56 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:24:56 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:24:56 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:25:02 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:25:28 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:26:50 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:26:50 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:26:50 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:30:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:30:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:30:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:33:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:33:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:33:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:33:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:33:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:33:11 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:33:36 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:38:58 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:38:58 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:38:58 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:42:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:42:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:42:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:42:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:42:57 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 77
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 78
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 79
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 15
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 16
ERROR - 2021-01-10 18:43:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 17
ERROR - 2021-01-10 18:43:24 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:47:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:47:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:47:26 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:48:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:48:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:48:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 18:55:16 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:55:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:55:39 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:55:39 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:55:39 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 77
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 78
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Undefined index: logged_user C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 79
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 15
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 16
ERROR - 2021-01-10 18:56:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\user.php 17
ERROR - 2021-01-10 18:56:32 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:58:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:58:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:58:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:58:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:58:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 18:58:25 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 18:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 18:58:32 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:58:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 18:58:32 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 18:58:32 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 19:00:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 19:00:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 19:00:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 19:00:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 19:00:14 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 19:00:16 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:00:32 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:00:46 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:00:49 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:01:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 37
ERROR - 2021-01-10 19:01:48 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 19:01:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 96
ERROR - 2021-01-10 19:01:48 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 125
ERROR - 2021-01-10 19:01:48 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\views\templates\redlabel\checkout.php 126
ERROR - 2021-01-10 19:02:11 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:03:14 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:03:26 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:03:33 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:03:33 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:03:33 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:36 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:36 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:36 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:04:42 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:01 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:01 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:01 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:04 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:06:46 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:07:19 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:07:20 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:07:20 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:16 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:16 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:16 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:58 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:58 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:08:58 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:31 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:31 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:31 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:34 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:34 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:09:34 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:17:41 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:17:41 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:17:41 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:29:28 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:29:28 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:29:28 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:30:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:30:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:30:14 --> 404 Page Not Found: /index
ERROR - 2021-01-10 19:32:43 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:32:46 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:50:29 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 19:50:41 --> Severity: error --> Exception: Call to undefined function ShowNotificator() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\models\Public_model.php 640
ERROR - 2021-01-10 19:58:21 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 70
ERROR - 2021-01-10 19:58:52 --> Severity: error --> Exception: Call to undefined function alert() C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\application\controllers\Users.php 69
ERROR - 2021-01-10 20:00:27 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 20:00:34 --> Could not find the language line "user_order_history"
ERROR - 2021-01-10 20:00:46 --> Could not find the language line "user_order_history"
