<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-09 17:01:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\xampp\htdocs\Ecommerce-CodeIgniter-Bootstrap-master\Ecommerce-CodeIgniter-Bootstrap-master\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-01-09 17:01:27 --> Unable to connect to the database
